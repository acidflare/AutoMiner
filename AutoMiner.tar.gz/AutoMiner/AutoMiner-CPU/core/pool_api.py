"""Pool API interaction for AutoMiner."""

import time
import json
import requests
import logging
from typing import Dict, List, Any, Optional

from .models import Pool

###START IPv4 FORCE PATCH###
# This block tells the 'requests' library to ignore IPv6
import requests.packages.urllib3.util.connection as urllib3_cn
import socket

def allowed_gai_family():
    """Force IPv4 for all requests."""
    return socket.AF_INET

# Apply the patch
urllib3_cn.allowed_gai_family = allowed_gai_family
# --- END PATCH ---

logger = logging.getLogger(__name__)


class PoolAPIClient:
    """Client for interacting with pool APIs."""
    
    def __init__(self, timeout: int = 30):
        """Initialize pool API client."""
        self.timeout = timeout
        
    def fetch_pool_data(self, pool: Pool) -> bool:
        """Fetch current data from pool API."""
        if not pool.api_url:
            logger.error(f"No API URL configured for pool {pool.name}")
            return False
            
        try:
            # logger.info(f"Fetching data from {pool.name} API...") 
            # Commented out to reduce log spam on frequent updates
            response = requests.get(pool.api_url, timeout=self.timeout)
            response.raise_for_status()
            
            pool.results = response.json()
            # CRITICAL FIX: Zpool API returns a dictionary of algorithms as top-level keys
            pool.supported_algos = list(pool.results.keys())
            
            # logger.info(f"Pool {pool.name} supports {len(pool.supported_algos)} algorithms")
            return True
            
        except requests.RequestException as e:
            logger.error(f"Failed to fetch data from {pool.name}: {e}")
            return False
        except ValueError as e:
            logger.error(f"Invalid JSON response from {pool.name}: {e}")
            return False

    def get_wallet_balance(self, pool: Pool) -> float:
        """Fetch the current pending balance for the wallet on this pool.
        
        Currently supports Zpool structure.
        """
        # Zpool Wallet API: https://zpool.ca/api/wallet?address=<WALLET>
        # This might need adjustment if you add other pools later.
        if "zpool" in pool.name.lower():
            url = f"https://zpool.ca/api/wallet?address={pool.wallet}"
            try:
                response = requests.get(url, timeout=self.timeout)
                response.raise_for_status()
                data = response.json()
                
                # Zpool returns: {"currency": "BTC", "unsold": 0.001, "balance": 0.005, ...}
                # We want the total unpaid balance (balance + unsold usually gives a good estimate, 
                # but 'balance' is the confirmed payout pending)
                
                # Let's grab 'balance' (confirmed) + 'unsold' (waiting to exchange) for a total pending view
                currency = data.get("currency", "")
                balance = float(data.get("balance", 0))
                unsold = float(data.get("unsold", 0))
                
                total_pending = balance + unsold
                pool.balance = total_pending # Update pool object
                pool.currency = currency
                return total_pending, currency
                
            except Exception as e:
                logger.warning(f"Failed to fetch wallet balance: {e}")
                return 0.0
        
        return 0.0
    
    def update_all_pools(self, pools: Dict[str, Pool]) -> Dict[str, bool]:
        """Update data for all pools."""
        results = {}
        
        for name, pool in pools.items():
            results[name] = self.fetch_pool_data(pool)
            # Also update balance during global update
            self.get_wallet_balance(pool)
            
        successful = sum(1 for success in results.values() if success)
        logger.info(f"Successfully updated {successful}/{len(pools)} pools")
        
        return results


def find_common_algorithms(miner_algos: List[str], pool_algos: List[str], 
                          algo_variations: Dict[str, List[str]]) -> Dict[str, str]:
    """Find algorithms supported by both miner and pool."""
    common = {}
    
    for miner_algo in miner_algos:
        # Direct match check (simplified)
        if miner_algo in pool_algos:
            common[miner_algo] = miner_algo
            continue
            
        # Check variations (using algos.json)
        if miner_algo in algo_variations:
            pool_expected_name = algo_variations[miner_algo][0] 
            if pool_expected_name in pool_algos:
                common[miner_algo] = pool_expected_name
                # logger.debug(f"Matched {miner_algo} to {pool_expected_name} via variations")
                continue
                
    # Fallback for simple name matching
    for miner_algo in miner_algos:
        if miner_algo not in common:
            miner_lower = miner_algo.lower()
            for pool_algo in pool_algos:
                if miner_lower == pool_algo.lower():
                    common[miner_algo] = pool_algo
                    break
    
    return common
