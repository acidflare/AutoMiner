"""Configuration management for AutoMiner."""

import json
import logging
from pathlib import Path
from typing import Dict, List, Any

logger = logging.getLogger(__name__)


class Config:
    """Manages configuration loading and access."""
    
    def __init__(self, data_dir: Path = None):
        """Initialize configuration manager."""
        self.data_dir = data_dir or Path("data")
        self.config = {}
        self.miners = {}
        self.pools = {}
        self.algos = []
        
    def load(self) -> None:
        """Load all configuration files."""
        try:
            self.config = self._load_json("config.json")
            self.miners = self._load_json("miners.json")
            self.pools = self._load_json("pools.json")
            self.algos = self._load_json("algos.json")
        except FileNotFoundError as e:
            logger.error(f"Missing configuration file: {e}")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in configuration file: {e}")
            raise
            
    def _load_json(self, filename: str) -> Dict[str, Any]:
        """Load a JSON file from the data directory."""
        filepath = self.data_dir / filename
        with open(filepath, 'r') as f:
            return json.load(f)
    
    # --- New Property ---
    @property
    def currency(self) -> str:
        """Get the user's preferred display currency."""
        return self.config.get("currency", "USD")

    @property
    def threads(self) -> int:
        """Get number of CPU threads to use."""
        return self.config.get("threads", 4)
        
    @property
    def worker_name(self) -> str:
        """Get the user-defined worker name."""
        return self.config.get("worker_name", "default_worker")

    @property
    def benchmark_period(self) -> int:
        """Get benchmark period in seconds."""
        return self.config.get("benchmark_period", 300)
    
    @property
    def min_shares(self) -> int:
        """Get minimum shares for complete benchmark."""
        return self.config.get("complete_benchmark_min_shares", 1000)
    
    @property
    def give_up_time(self) -> int:
        """Get time to give up on low profit benchmarks."""
        return self.config.get("give_up_benchmark_low_profit_secs", 30)
    
    @property
    def min_profit(self) -> float:
        """Get minimum profit threshold in USD/day."""
        return self.config.get("min_profit", 0.01)
    
    @property
    def max_rejected_shares(self) -> int:
        """Get maximum rejected shares before giving up."""
        return self.config.get("max_rejected_shares", 2)
    
    @property
    def session_timeout(self) -> int:
        """Get session timeout in seconds."""
        return self.config.get("session_timeout", 300)
    
    @property
    def blacklisted_algos(self) -> List[str]:
        """Get list of blacklisted algorithms."""
        return self.config.get("blacklisted_algos", [])
