"""Profitability calculation for AutoMiner."""

import requests
import logging
import time
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass

from .models import Pool, Miner

logger = logging.getLogger(__name__)


@dataclass
class ProfitEntry:
    """Entry in profitability table."""
    miner: str
    pool: str
    algo: str
    profit: float
    currency: str = "USD"

    def to_list(self) -> List[str]:
        """Convert to list for table display."""
        return [self.miner, self.pool, self.algo, f"{self.profit:.5f} {self.currency}"]


class ProfitabilityCalculator:
    """Calculates mining profitability."""

    def __init__(self, config: Any = None):
        """Initialize profitability calculator.

        Args:
            config: The global Config object (optional, can be set later)
        """
        self.config = config
        self._btc_price = 0.0
        self._target_currency = "USD"
        self._last_price_update = 0.0
        # Default timeout if config isn't provided immediately
        self._default_timeout = 600

        # Initialize results to prevent AttributeError
        self.results = {}

    def _should_update_price(self) -> bool:
        """Check if the Bitcoin price needs updating based on session timeout."""
        if self._last_price_update == 0.0:
            return True

        timeout = self._default_timeout
        if self.config:
            # Access session_timeout directly from the config object
            timeout = getattr(self.config, 'session_timeout', self._default_timeout)

        current_time = time.time()
        return (current_time - self._last_price_update) >= timeout

    def update_bitcoin_price(self, force: bool = False) -> float:
        """Fetch current Bitcoin price in target currency."""
        # Determine target currency from config
        target_currency = "USD"
        if self.config and hasattr(self.config, 'currency'):
            target_currency = self.config.currency.upper()

        self._target_currency = target_currency

        if not force and not self._should_update_price():
            return self._btc_price

        try:
            url = f"https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies={target_currency.lower()}"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()

            if 'bitcoin' in data and target_currency.lower() in data['bitcoin']:
                price = float(data['bitcoin'][target_currency.lower()])
                self._btc_price = price
                self._last_price_update = time.time()
                logger.info(f"Updated Bitcoin price: {price:.2f} {target_currency}")
                return self._btc_price
            else:
                logger.warning(f"Currency {target_currency} not found in API response, falling back to USD")

        except Exception as e:
            logger.warning(f"Failed to fetch price for {target_currency}: {e}")

        # Fallback to USD if specific currency fetch failed
        if self._btc_price == 0.0:
            try:
                url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
                response = requests.get(url, timeout=10)
                data = response.json()
                self._btc_price = float(data['bitcoin']['usd'])
                self._target_currency = "USD"
                logger.info(f"Fallback: Updated Bitcoin price: ${self._btc_price:.2f} USD")
            except:
                self._btc_price = 90000.0
                logger.warning(f"Using hardcoded fallback Bitcoin price")

        return self._btc_price

    @property
    def btc_price(self) -> float:
        """Get current BTC price in target currency."""
        return self.update_bitcoin_price()

    def get_profit_table(self, miners: Dict[str, Miner], pools: Dict[str, Pool],
                         min_profit: float = 0.0, blacklisted_algos: List[str] = None) -> List[ProfitEntry]:
        """Generate profitability table for all combinations."""
        entries = []
        blacklisted_algos = blacklisted_algos or []

        # Ensure price is fresh
        self.update_bitcoin_price()

        for miner_name, miner in miners.items():
            for pool_name, pool in pools.items():
                for algo, hashrate in miner.benchmarks.items():
                    if algo in blacklisted_algos:
                        continue

                    if hashrate > 0:
                        pool_algo = pool.find_algo_name(algo)
                        if pool_algo:
                            # -----------------------------------------------------
                            # FIX: Unit Correction (H/s vs kH/s)
                            # -----------------------------------------------------
                            # Calculate the raw profit first
                            raw_profit = pool.calculate_profitability(pool_algo, hashrate, self._btc_price)

                            # Apply Correction: Divide by 1000
                            profit = raw_profit / 1000.0

                            if profit >= min_profit:
                                entries.append(ProfitEntry(
                                    miner=miner_name,
                                    pool=pool_name,
                                    algo=algo,
                                    profit=profit,
                                    currency=self._target_currency
                                ))

        entries.sort(key=lambda x: x.profit, reverse=True)
        return entries

    def calculate_for_pool(self, pool: Pool, algo: str, hashrate: int) -> float:
        """Calculate profitability for specific pool and algorithm with Unit Fix."""
        pool_algo = pool.find_algo_name(algo)
        if not pool_algo:
            return 0.0

        # Ensure we have a price
        if self._btc_price == 0.0:
            self.update_bitcoin_price()

        # Calculate raw profit
        raw_profit = pool.calculate_profitability(pool_algo, hashrate, self._btc_price)

        # FIX: Apply the same division by 1000 here so Live Stats match the Table
        return raw_profit / 1000.0

    def find_most_profitable(self, miners: Dict[str, Miner], pools: Dict[str, Pool],
                             min_profit: float = 0.0, blacklisted_algos: List[str] = None) -> Optional[Tuple[str, str, str, float]]:
        """Find most profitable miner/pool/algorithm combination."""
        profit_table = self.get_profit_table(miners, pools, min_profit, blacklisted_algos)

        if profit_table:
            entry = profit_table[0]
            return entry.miner, entry.pool, entry.algo, entry.profit

        return None
