"""Data models for AutoMiner."""

import os
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import json
import logging

logger = logging.getLogger(__name__)

# =================SYSTEM PRIORITY=================
def set_low_priority():
    """
    Sets the current process niceness to 15.
    15 is a low priority (background), ensuring the desktop remains responsive,
    but slightly higher priority than the absolute minimum (19).
    """
    try:
        # os.nice(0) returns the current niceness.
        # We calculate the difference needed to get to 15.
        current_nice = os.nice(0)
        target_nice = 19
        increment = target_nice - current_nice

        if increment > 0:
            new_nice = os.nice(increment)
            print(f"[System] Process niceness set to {new_nice} (Background Priority)")
        else:
            print(f"[System] Process already at nice level {current_nice}")
            
    except OSError as e:
        print(f"[System] Warning: Could not set niceness: {e}")

# Call this immediately when the script loads
set_low_priority()
# =================================================

@dataclass
class PoolParams:
    """Parameters for connecting to a mining pool."""
    algo: str
    wallet: str
    password: str
    url: str
    port: int
    api_host: str = "127.0.0.1"
    api_port: int = 40101
    
    threads: int = 4 
    worker_name: str = "default_worker"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for string formatting."""
        return {
            "algo": self.algo,
            "wallet": self.wallet,
            "password": self.password,
            "url": self.url,
            "port": self.port,
            "API_HOST": self.api_host,
            "API_PORT": self.api_port,
            "threads": self.threads, 
            "worker": self.worker_name,
            "algorithm": self.algo, 
            "pool": self.url  
        }


@dataclass
class BenchmarkResult:
    """Result of a benchmark run."""
    algo: str
    hashrate: int
    accepted_shares: int
    rejected_shares: int
    duration: float
    

class Miner:
    """Represents a mining software configuration."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """Initialize miner."""
        self.name = name
        self.config = config 
        self.supported_algos = config.get("algorithms", [])
        self.benchmarks = {}
        
    def load_benchmarks(self) -> None:
        """Load benchmark results from file."""
        filename = f"benchmark-{self.name}.json"
        try:
            with open(filename, 'r') as f:
                self.benchmarks = json.load(f)
            logger.info(f"Loaded benchmarks from {filename}")
        except FileNotFoundError:
            logger.info(f"No existing benchmark file {filename}, starting fresh")
            self.benchmarks = {}
    
    def save_benchmarks(self) -> None:
        """Save benchmark results to file."""
        filename = f"benchmark-{self.name}.json"
        with open(filename, 'w') as f:
            json.dump(self.benchmarks, f, sort_keys=True, indent=4)
        logger.info(f"Saved benchmarks to {filename}")
    
    def get_supported_algos(self) -> List[str]:
        """Get list of all supported algorithms."""
        return self.supported_algos
    
    def build_command(self, binary_path: str, algo: str, pool_params: PoolParams) -> List[str]:
        """Build command line for launching miner."""
        cmdline = [binary_path]
        
        command_template = self.config.get("command_template", "")
        
        launch_args = command_template.format(**pool_params.to_dict())
        
        cmdline.extend(launch_args.split())
        return cmdline


class Pool:
    """Represents a mining pool configuration."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """Initialize pool."""
        self.name = name
        self.config = config
        
        self.wallet = config.get("wallet", "")
        self.password = config.get("password", "x")
        self.mine_url = config.get("mine_url", "")
        self.api_url = config.get("api_url", "") 
        self.results = {}
        self.supported_algos = []
        self.balance = 0.0 # New field for wallet balance
        
    def get_miner_api_port(self, miner_name: str) -> int:
                """Determines the correct API port based on the miner type."""
                name_lower = miner_name.lower()
                
                # SRB Miner uses 21550 (Confirmed by user)
                if "srbminer" in name_lower:
                    return 21550
                    
                # WildRig uses 21554 (GPU)
                elif "wildrig" in name_lower:
                    return 21554
                    
                # XMRig often defaults to 37600
                elif "xmrig" in name_lower:
                    return 37600

                # lolMiner often uses 44440
                elif "lolminer" in name_lower:
                    return 44440     
                    
                # Default Fallback (CPUMiner/General)
                return 4049
        
    def create_params(self, algo: str, global_config: Any, miner_name: str, api_host: str = "127.0.0.1") -> Optional[PoolParams]:
        """Create pool parameters for given algorithm."""
        
        pool_algo = self.find_algo_name(algo)
        if not pool_algo or pool_algo not in self.results:
            return None
            
        # CRITICAL FIX: The API Port in the parameters must reflect the miner's expected binding port.
        api_port = self.get_miner_api_port(miner_name)
            
        return PoolParams(
            algo=algo,
            wallet=self.wallet,
            password=self.password,
            # The 'port' variable below is the STRATUM port, not the API port.
            url=self.mine_url.format(algo=pool_algo, port=self.results[pool_algo]["port"]), 
            port=self.results[pool_algo]["port"], 
            api_host=api_host,
            api_port=api_port, # <-- This value (e.g. 21550) is used by the command template
            threads=global_config.threads, 
            worker_name=global_config.worker_name
        )
    
    def find_algo_name(self, algo: str) -> Optional[str]:
        """Find the pool's name for an algorithm."""
        if algo in self.results:
            return algo
        
        algo_lower = algo.lower()
        for pool_algo in self.results:
            if pool_algo.lower() == algo_lower:
                return pool_algo
                
        return None
    
    def calculate_profitability(self, algo: str, hashrate: int, 
                               mbtc_price: float) -> float:
        """Calculate profitability for given algorithm and hashrate."""
        if algo not in self.results:
            return 0.0
            
        algo_data = self.results[algo]
        estimate = float(algo_data.get("estimate_current", 0)) * 1000
        mh_factor = float(algo_data.get("mbtc_mh_factor", 1))
        
        hashrate_mh = hashrate / 1_000_000
        return (estimate * (hashrate_mh / mh_factor) * mbtc_price)