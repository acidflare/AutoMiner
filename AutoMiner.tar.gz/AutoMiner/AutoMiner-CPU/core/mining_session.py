"""Mining session management for AutoMiner."""

import subprocess
import time
import logging
import os
from typing import Optional, Dict, Any

from .models import Miner, Pool
from .api_client import MinerAPIClient
from .profit import ProfitabilityCalculator

logger = logging.getLogger(__name__)

# List of known miner binary names for clean shutdown
# NOTE: This list now contains only the main executable names.
KNOWN_MINERS = [
    "cpuminer", "cpuminer-big", "cpuminer-little", 
    "cpuminer-armv9-x2", "cpuminer-armv9-a710", "cpuminer-armv9-a510",
    "cpuminer-armv8.2-a78", "cpuminer-armv8.2-a55", "cpuminer-armv8-a53",
    "SRBMiner-MULTI", "teamredminer", "lolMiner"
]

# Specific components of XMRig that must be checked for rogue status
XMRIG_TARGETS = [
    "xmrigMiner", 
    "xmrigDaemon"
]

def kill_zombies():
    """
    Conditionally kills orphaned XMRig worker processes (Miner running without Daemon).
    This function checks if the xmrigMiner process is running WITHOUT the 
    xmrigDaemon supervisor, indicating an orphaned 'zombie' worker.
    """
    
    # 1. Check if the Daemon is active (The supervisor) - Checked first
    # This checks for the main daemon process (supervisor)
    daemon_check = subprocess.run(
        "pgrep -f xmrigDaemon | wc -l", 
        shell=True, 
        capture_output=True, 
        text=True
    )
    # Convert command output (count of processes) to integer
    daemon_count = int(daemon_check.stdout.strip())
    
    # 2. Check if the Miner component (the worker) is active
    # This checks for the worker process that consumes CPU
    miner_check = subprocess.run(
        "pgrep -f xmrigMiner | wc -l", 
        shell=True, 
        capture_output=True, 
        text=True
    )
    miner_count = int(miner_check.stdout.strip())
    
    logger.debug(f"[ZOMBIE CHECK] Daemon count: {daemon_count}, Miner count: {miner_count}")

    # Logic: Miner is orphaned if miner_count > 0 AND daemon_count == 0
    # This is the fail condition: Worker is active, but supervisor is missing.
    if miner_count > 0 and daemon_count == 0:
        logger.warning("[ZOMBIE KILLER] Orphaned xmrigMiner detected. Initiating aggressive kill.")
        try:
            # Kill the rogue worker processes
            subprocess.run("pkill -9 -f xmrigMiner", shell=True, stderr=subprocess.DEVNULL)
            logger.info("Orphaned xmrigMiner processes terminated.")
        except Exception as e:
            logger.error(f"Error during aggressive kill: {e}")
            
    # Always ensure the environment is clean for the next start
    time.sleep(0.5)


class MiningSession:
    """Manages a mining session."""
    
    def __init__(self, config: Dict[str, Any], api_client: MinerAPIClient,
                 profit_calc: ProfitabilityCalculator):
        """Initialize mining session."""
        self.config = config
        self.api_client = api_client
        self.profit_calc = profit_calc
        self.current_algo = ""
        self.current_process = None
        self.session_start = None
        self.current_pool_params = None 
        
        # Watchdog Variables
        self.zero_hash_strikes = 0
        self.MAX_STRIKES = 50 
        self.GRACE_PERIOD_SECS = 60
        
        # New Flag: Tracks if the startup success message has been logged
        self.grace_period_logged = False
        
    def start(self, miner: Miner, pool: Pool, algo: str, binary_path: str) -> bool:
        """Start a new mining session."""
        # Stop current session if running
        if self.current_process:
            self.stop()
            
        # WATCHDOG 1: The Zombie Killer (KEPT)
        # This only cleans up lingering XMRig processes left by the *previous* run.
        # This is where the logic is applied, between switches.
        kill_zombies()
        
        # Reset Watchdog counters
        self.zero_hash_strikes = 0
        self.grace_period_logged = False # Reset flag for new session
        
        # Create pool parameters (includes API host/port)
        # We need the miner name to determine the correct API port
        pool_params = pool.create_params(algo, self.config, miner_name=miner.name) 
        if not pool_params:
            logger.error(f"Failed to create pool parameters for {algo}")
            return False
        
        # Store params for monitoring later
        self.current_pool_params = pool_params 

        # Build command line
        cmdline = miner.build_command(binary_path, algo, pool_params)
        logger.info(f"Starting mining session: {' '.join(cmdline)}")
        
        try:
            self.current_process = subprocess.Popen(
                cmdline,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            self.current_algo = algo
            self.session_start = time.time()
            
            logger.info(f"Mining process started with PID {self.current_process.pid}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start mining process: {e}")
            return False
    
    def stop(self) -> None:
        """Stop current mining session."""
        if not self.current_process:
            return
            
        logger.info(f"Stopping mining session for {self.current_algo}")
        
        # Try graceful termination first
        self.current_process.terminate()
        try:
            self.current_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            logger.warning("Process did not terminate gracefully, killing...")
            self.current_process.kill()
            self.current_process.wait()
            
        # Optional: Run zombie killer again if the miner being stopped was XMRig
        # This double-taps the cleanup for the problematic miner
        if self.current_algo and "xmrig" in self.current_algo.lower():
             logger.info("Aggressively cleaning XMRig components.")
             kill_zombies()
            
        self.current_process = None
        self.current_algo = ""
        self.session_start = None
        self.current_pool_params = None
    
    def is_running(self) -> bool:
        """Check if mining session is running."""
        if not self.current_process:
            return False
        return self.current_process.poll() is None
    
    def should_switch(self, current_profit: float, best_profit: float, 
                     best_algo: str) -> bool:
        """Determine if we should switch algorithms."""
        if not self.is_running():
            return True
            
        if self.current_algo != best_algo:
            profit_threshold = 0.01
            if best_profit > current_profit + profit_threshold:
                logger.info(f"Better algorithm available: {best_algo} "
                          f"(${best_profit:.4f} vs ${current_profit:.4f})")
                return True
        
        return False
    
    def get_session_duration(self) -> float:
        """Get current session duration in seconds."""
        if not self.session_start:
            return 0
        return time.time() - self.session_start
    
    def monitor(self, pool: Pool) -> Optional[Dict[str, Any]]:
        """Monitor current mining session."""
        if not self.is_running() or not self.current_pool_params:
            return None
            
        try:
            # Pass host and port to the API client call
            hashrate, accepted, rejected = self.api_client.get_hashrate_and_shares(
                self.current_pool_params.api_host, self.current_pool_params.api_port
            )
            
            # --- START GRACE PERIOD CHECK (Silenced Log Spam) ---
            if self.get_session_duration() < self.GRACE_PERIOD_SECS:
                # Log only IF hashrate becomes positive for the first time AND the flag is False
                if hashrate > 0.0 and not self.grace_period_logged:
                    logger.info(f"Miner started successfully within grace period ({self.get_session_duration():.1f}s)")
                    self.grace_period_logged = True # Set flag to prevent future logging
                
                # Reset strikes immediately if in grace period, preventing accumulation
                self.zero_hash_strikes = 0
            # --- END GRACE PERIOD CHECK ---
            
            # WATCHDOG 2: Zero-Hash Monitor
            elif hashrate <= 0.0:
                self.zero_hash_strikes += 1
                if self.zero_hash_strikes % 10 == 0:
                    logger.warning(f"Hashrate 0.00 strike {self.zero_hash_strikes}/{self.MAX_STRIKES}")
                
                if self.zero_hash_strikes >= self.MAX_STRIKES:
                    logger.error(f"WATCHDOG TRIGGERED: Miner hung for {self.MAX_STRIKES}s. Restarting...")
                    self.stop() # Kill the process
                    return None # Return None to signal main loop that session ended
            else:
                if self.zero_hash_strikes > 0:
                    logger.info(f"Hashrate recovered ({hashrate} H/s). Strikes reset.")
                self.zero_hash_strikes = 0
            
            profit = self.profit_calc.calculate_for_pool(pool, self.current_algo, hashrate)
            
            return {
                "algo": self.current_algo,
                "hashrate": hashrate,
                "accepted_shares": accepted,
                "rejected_shares": rejected,
                "profit": profit,
                "duration": self.get_session_duration()
            }
        except Exception as e:
            # Log the connection failure, but do not kill the miner.
            logger.warning(f"Failed to get session stats: {e}")
            return None