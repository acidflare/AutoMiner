"""API client for communicating with miners (XMRig, SRBMiner, lolMiner, WildRig, CPUMiner)."""

import socket
import logging
import time
import json
import requests
from typing import Tuple

# --- START IPv4 FORCE PATCH ---
import requests.packages.urllib3.util.connection as urllib3_cn
import socket as skt
def allowed_gai_family(): return skt.AF_INET
urllib3_cn.allowed_gai_family = allowed_gai_family
# --- END PATCH ---
logger = logging.getLogger(__name__)

class MinerAPIClient:
    """Client for communicating with miner APIs."""

    def __init__(self):
        self.max_retries = 5  # Increased overall retries for stability
        self.retry_delay = 2  # Standard 1-second delay between connection attempts

    def get_hashrate_and_shares(self, host: str, port: int) -> Tuple[float, int, int]:
        """Get current hashrate and share counts from any supported miner.
        Returns: Tuple of (hashrate, accepted_shares, rejected_shares)
        """
        # CRITICAL FIX: Increased timeout to 10 seconds for reliable miner API startup (SRBMiner, XMRig)
        HTTP_TIMEOUT = 10 
        
        for attempt in range(self.max_retries):
            # 1. Try HTTP-based APIs (SRBMiner, XMRig, lolMiner)
            try:
                # Fetch root JSON first (Used by SRBMiner, WildRig, lolMiner)
                response = requests.get(f"http://{host}:{port}/", timeout=HTTP_TIMEOUT)
                if response.status_code == 200:
                    try:
                        data = response.json()

                        # DETECT WILDRIG-MULTI
                        if 'ua' in data and 'WildRig' in data.get('ua', ''):
                            return self._get_wildrig_stats(data)

                        # DETECT SRBMINER-MULTI
                        if 'algorithms' in data:
                            return self._get_srbminer_stats(data)

                        # DETECT LOLMINER (New & Old)
                        if 'Algorithms' in data or 'Session' in data:
                            return self._get_lolminer_stats(data)

                    except json.JSONDecodeError:
                        pass # Not JSON

                # Try XMRig specific path (/1/summary)
                response_xmrig = requests.get(f"http://{host}:{port}/1/summary", timeout=HTTP_TIMEOUT)
                if response_xmrig.status_code == 200:
                    return self._get_xmrig_stats(response_xmrig.json())

            except (requests.exceptions.RequestException, ValueError, socket.error):
                # Connection failed, wait and retry
                pass

            # 2. Try TCP-based APIs (CPUMiner)
            try:
                return self._get_cpuminer_stats(host, port)
            except (socket.error, ConnectionRefusedError, OSError):
                # Connection failed, wait and retry
                pass
            
            # If all connection methods failed on this attempt, pause before the next loop iteration
            if attempt < self.max_retries - 1:
                time.sleep(self.retry_delay)

        # If we reach here after 5 retries, the miner is likely truly hung
        return 0.0, 0, 0

    def _get_wildrig_stats(self, data: dict) -> Tuple[float, int, int]:
        """Parse WildRig Multi JSON."""
        # Hashrate is an array in ["hashrate"]["total"]. Index 0 is 1s avg.
        hashrate_data = data.get('hashrate', {}).get('total', [0])
        hashrate = float(hashrate_data[0] if hashrate_data else 0)

        results = data.get('results', {})
        accepted = int(results.get('shares_good', 0))
        total = int(results.get('shares_total', 0))
        return hashrate, accepted, total - accepted

    def _get_xmrig_stats(self, data: dict) -> Tuple[float, int, int]:
        hashrate = float(data.get('hashrate', {}).get('total', [0])[0] or 0)
        results = data.get('results', {})
        accepted = int(results.get('shares_good', 0))
        total = int(results.get('shares_total', 0))
        return hashrate, accepted, total - accepted

    def _get_srbminer_stats(self, data: dict) -> Tuple[float, int, int]:
        main_algo = data['algorithms'][0]

        gpu_hash = main_algo.get('hashrate', {}).get('gpu', {}).get('total', 0.0)
        cpu_hash = main_algo.get('hashrate', {}).get('cpu', {}).get('total', 0.0)
        total_hashrate = (float(gpu_hash) if gpu_hash else 0.0) + (float(cpu_hash) if cpu_hash else 0.0)

        shares = main_algo.get('shares', {})
        return total_hashrate, int(shares.get('accepted', 0)), int(shares.get('rejected', 0))

    def _get_lolminer_stats(self, data: dict) -> Tuple[float, int, int]:
        # NEW STRUCTURE (v1.98a+) - Uses 'Algorithms' list
        if 'Algorithms' in data and len(data['Algorithms']) > 0:
            algo_data = data['Algorithms'][0]
            hashrate = float(algo_data.get('Total_Performance', 0.0))
            accepted = int(algo_data.get('Total_Accepted', 0))
            rejected = int(algo_data.get('Total_Rejected', 0))
            return hashrate, accepted, rejected

        # OLD STRUCTURE - Uses Session params
        session = data.get('Session', {})
        hashrate = float(session.get('Performance_Summary', 0.0) or session.get('Total_Performance', 0.0))
        accepted = int(session.get('Accepted', 0))
        rejected = int(session.get('Submitted', 0)) - accepted
        return hashrate, accepted, rejected

    def _get_cpuminer_stats(self, host: str, port: int) -> Tuple[float, int, int]:
        """Handles Raw TCP APIs (CPUMiner)."""
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5) # CPUMiner timeout remains 5s
        try:
            s.connect((host, port))
            s.sendall(b'summary')

            response = ""
            while True:
                chunk = s.recv(4096).decode('utf-8')
                if not chunk: break
                response += chunk
                if '|' in response or '}' in response: break
            s.close()

            data = {}
            parts = response.replace('|', '').replace(';', ';').split(';')
            for part in parts:
                if '=' in part:
                    key, value = part.split('=', 1)
                    data[key.strip()] = value.strip()

            if "HS" in data:
                hashrate = float(data["HS"])
            elif "KHS" in data:
                hashrate = float(data["KHS"]) * 1000
            else:
                hashrate = 0.0

            return hashrate, int(data.get("ACC", 0)), int(data.get("REJ", 0))
        except Exception:
            s.close()
            raise