"""Main entry point for AutoMiner."""

import argparse
import sys
import time
import logging
import select  # Added for non-blocking input
from pathlib import Path
from typing import Dict, Any, Optional
from tabulate import tabulate

from .config import Config
from .models import Miner, Pool
from .api_client import MinerAPIClient
from .pool_api import PoolAPIClient, find_common_algorithms
from .profit import ProfitabilityCalculator
from .benchmark import Benchmarker
from .mining_session import MiningSession
from .logger import setup_logging

# For raw input mode (Unix/Linux/Termux only)
import tty
import termios

logger = logging.getLogger(__name__)


class AutoMiner:
    """Main application class for AutoMiner."""
    
    def __init__(self, data_dir: Optional[Path] = None):
        """Initialize AutoMiner."""
        self.config = Config(data_dir)
        self.api_client = MinerAPIClient()
        self.pool_client = PoolAPIClient()
        self.profit_calc = ProfitabilityCalculator(self.config)
        
        self.miners: Dict[str, Miner] = {}
        self.pools: Dict[str, Pool] = {}
        
    def initialize(self) -> None:
        """Initialize application."""
        logger.info("Initializing AutoMiner...")
        
        self.config.load()
        
        for name, config in self.config.miners.items():
            self.miners[name] = Miner(name, config)
            
        for name, config in self.config.pools.items():
            self.pools[name] = Pool(name, config)
        
        self._populate_supported_algorithms()
        
        for miner in self.miners.values():
            miner.load_benchmarks()
    
    def _populate_supported_algorithms(self) -> None:
        """Populate supported algorithms for miners and pools."""
        for name, miner in self.miners.items():
            miner.supported_algos = miner.get_supported_algos()
            logger.info(f"Miner {name} supports {len(miner.supported_algos)} algorithms")
        
        logger.info("Fetching pool data...")
        self.pool_client.update_all_pools(self.pools)
    
    def run_benchmarks(self, skip_existing: bool = True) -> None:
        """Run benchmarks for all miner/pool/algorithm combinations."""
        benchmarker = Benchmarker(self.config.config, self.api_client, self.profit_calc)
        
        for miner_name, miner in self.miners.items():
            binary_path = miner.config.get('executable')
            if not binary_path:
                logger.warning(f"Skipping miner {miner_name}: 'executable' path missing in config.")
                continue

            for pool_name, pool in self.pools.items():
                common_algos = find_common_algorithms(
                    miner.supported_algos,
                    pool.supported_algos,
                    self.config.algos
                )
                
                logger.info(f"{miner_name} and {pool_name} have {len(common_algos)} algorithms in common")
                
                for algo, pool_algo in common_algos.items():
                    if algo in self.config.blacklisted_algos:
                        logger.debug(f"Skipping blacklisted algorithm: {algo}")
                        continue
                        
                    if skip_existing and algo in miner.benchmarks:
                        logger.debug(f"Skipping existing benchmark: {algo}")
                        continue
                    
                    pool_params = pool.create_params(algo, self.config, miner_name=miner_name)
                    
                    if not pool_params:
                        logger.warning(f"Failed to create pool params for {algo}")
                        continue
                    
                    hashrate = benchmarker.run_benchmark(
                        miner, algo, pool, pool_params, binary_path
                    )
                    
                    miner.benchmarks[algo] = hashrate
                    miner.save_benchmarks()
    
    def print_profit_table(self) -> None:
        """Print current profitability table."""
        profit_table = self.profit_calc.get_profit_table(
            self.miners, 
            self.pools,
            self.config.min_profit,
            self.config.blacklisted_algos
        )
        
        if profit_table:
            table_data = [entry.to_list() for entry in profit_table]
            print("\nProfitability Table:")
            print(tabulate(table_data, headers=["Miner", "Pool", "Algorithm", "Profit/Day"]))
        else:
            print("\nNo profitable algorithms found.")

    def _is_data_available(self) -> bool:
        """Check if data is available on stdin without blocking."""
        return select.select([sys.stdin], [], [], 0) == ([sys.stdin], [], [])

    def run_mining_loop(self) -> None:
        """Run main mining loop with automatic switching."""
        session = MiningSession(self.config, self.api_client, self.profit_calc)
        
        logger.info("Starting mining loop...")
        print("Press 'q' at any time to quit")
        
        # --- RAW MODE SETUP ---
        # Save original terminal settings
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        
        try:
            # Set terminal to raw mode (reads char by char)
            tty.setcbreak(fd)
            
            while True:
                # --- CHECK FOR QUIT KEY (Outer Loop) ---
                if self._is_data_available():
                    key = sys.stdin.read(1)
                    if key.lower() == 'q':
                        logger.info("Quit command received. Stopping processes!")
                        break

                try:
                    result = self.profit_calc.find_most_profitable(
                        self.miners, 
                        self.pools,
                        self.config.min_profit,
                        self.config.blacklisted_algos
                    )
                    
                    if not result:
                        logger.warning("No profitable algorithm found")
                        # Restore settings momentarily to print normally if needed
                        print("\nNo profitable algorithm found. Waiting 60 seconds...")
                        print(f"Check config.json - minimum profit threshold: ${self.config.min_profit}/day")
                        
                        # Wait loop with quit check
                        for _ in range(60):
                            if self._is_data_available():
                                if sys.stdin.read(1).lower() == 'q':
                                    raise KeyboardInterrupt
                            time.sleep(1)
                        continue
                    
                    miner_name, pool_name, algo, profit = result
                    
                    miner_instance = self.miners[miner_name]
                    binary_path = miner_instance.config.get('executable')
                    
                    self.config.current_miner_name = miner_name 
                    pool_params = self.pools[pool_name].create_params(algo, self.config, miner_name=miner_name) 
                    
                    if not pool_params:
                        logger.warning(f"Failed to create pool params for {algo}. Skipping mining loop.")
                        time.sleep(10)
                        continue

                    current_stats = None
                    if session.is_running():
                        current_stats = session.monitor(self.pools[pool_name])
                    
                    should_switch = True
                    if current_stats:
                        should_switch = session.should_switch(
                            current_stats["profit"],
                            profit,
                            algo
                        )
                    
                    if should_switch:
                        logger.info(f"Switching to {miner_name} on {algo}@{pool_name} (${profit:.4f}/day)")
                        session.start(
                            miner_instance,
                            self.pools[pool_name],
                            algo,
                            binary_path 
                        )
                        self.pool_client.get_wallet_balance(self.pools[pool_name])
                    
                    session_end = time.time() + self.config.session_timeout
                    
                    # ANSI escape code to clear the line
                    CLEAR_LINE = "\033[K"
                    
                    while time.time() < session_end:
                        if not session.is_running():
                            logger.warning("Mining process terminated unexpectedly")
                            break
                        
                        # --- CHECK FOR QUIT KEY (Inner Mining Loop) ---
                        if self._is_data_available():
                            key = sys.stdin.read(1)
                            if key.lower() == 'q':
                                logger.info("Quit command received. Stopping processes!")
                                session.stop()
                                return # Exit function entirely

                        stats = session.monitor(self.pools[pool_name])
                        if stats:
                            current_balance = getattr(self.pools[pool_name], 'balance', 0.0)
                            current_currency = getattr(self.pools[pool_name], 'currency', '???')
                            
                            # Direct inline truncation of existing variable
                            algo_truncated = stats['algo'][:9] + "." if len(stats['algo']) > 10 else stats['algo']

                            print(f"\r{CLEAR_LINE}[{algo_truncated}] $: {stats['profit']:.4f} {self.config.currency}/D|"
                                  f"H: {int(stats['hashrate'])}|"
                                  f"B: {current_balance:.6f} {current_currency}|"
                                  f"T: {int(session_end - time.time())}s",
                                  f"{CLEAR_LINE}", 
                                  end="", flush=True)
                        
                        time.sleep(1)
                    
                    print() # New line after loop finishes
                    
                    self.pool_client.update_all_pools(self.pools)
                    
                except KeyboardInterrupt:
                    logger.info("Shutting down...")
                    break
                except Exception as e:
                    logger.error(f"Fatal error: {e}", exc_info=True)
                    time.sleep(10)
        
        finally:
            # --- RESTORE TERMINAL SETTINGS ---
            # This is critical. If we crash or exit, we must give the terminal back
            # or it will look broken (no echo, weird formatting).
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            session.stop()


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="AutoMiner - mining profitability switcher"
    )
    parser.add_argument(
        '--data-dir',
        type=Path,
        help='Data directory containing configuration files (default: ./data)'
    )
    parser.add_argument(
        '--log-level',
        default='INFO',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        help='Logging level (default: INFO)'
    )
    parser.add_argument(
        '--log-file',
        type=Path,
        help='Log file path (optional)'
    )
    parser.add_argument(
        '--benchmark-only',
        action='store_true',
        help='Run benchmarks only, do not start mining'
    )
    parser.add_argument(
        '--force-benchmark',
        action='store_true',
        help='Force re-run all benchmarks'
    )
    
    args = parser.parse_args()
    
    setup_logging(args.log_level, args.log_file)
    
    try:
        app = AutoMiner(args.data_dir)
        app.initialize()
        
        for name, miner in app.miners.items():
            if not Path(miner.config.get('executable', '')).exists():
                logger.error(f"Miner executable not found for '{name}' at path: {miner.config.get('executable')}")
                logger.error("Please ensure the binaries are compiled and placed correctly.")
                sys.exit(1)
        
        app.run_benchmarks(skip_existing=not args.force_benchmark)
        app.print_profit_table()
        
        if not args.benchmark_only:
            app.run_mining_loop()
            
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()