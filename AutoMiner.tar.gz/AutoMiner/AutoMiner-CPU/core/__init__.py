"""AutoMiner - mining profitability switcher."""

__version__ = "1.0"
