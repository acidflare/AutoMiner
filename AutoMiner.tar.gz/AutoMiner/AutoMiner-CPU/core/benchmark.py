"""Benchmarking functionality for AutoMiner."""

import subprocess
import time
import logging
from typing import Optional, Dict, Any
import contextlib

from .models import Miner, Pool, PoolParams, BenchmarkResult
from .api_client import MinerAPIClient
from .profit import ProfitabilityCalculator
# Import the zombie killer to ensure clean benchmarks
from .mining_session import kill_zombies

logger = logging.getLogger(__name__)


class Benchmarker:
    """Handles algorithm benchmarking."""
    
    def __init__(self, config: Dict[str, Any], api_client: MinerAPIClient,
                 profit_calc: ProfitabilityCalculator):
        """Initialize benchmarker."""
        self.config = config
        self.api_client = api_client
        self.profit_calc = profit_calc
        
    def run_benchmark(self, miner: Miner, algo: str, pool: Pool, 
                     pool_params: PoolParams, binary_path: str) -> int:
        """Run a benchmark for specific algorithm."""
        logger.info(f"Starting benchmark for {miner.name} - {algo} on {pool.name}")
        
        # CRITICAL FIX: Kill any lingering miners before benchmarking
        # This prevents false low hashrates caused by zombie processes eating CPU/GPU
        kill_zombies()
        
        # Build command line
        cmdline = miner.build_command(binary_path, algo, pool_params)
        logger.debug(f"Command: {' '.join(cmdline)}")
        
        # Start miner process
        try:
            proc = subprocess.Popen(cmdline, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception as e:
            logger.error(f"Failed to start miner: {e}")
            return 0
        
        # Wait for startup
        with contextlib.suppress(subprocess.TimeoutExpired):
            outs, errs = proc.communicate(timeout=5)
            if proc.returncode is not None:
                logger.error(f"Miner crashed during startup - possibly unsupported algorithm")
                return 0
        
        # Run benchmark
        try:
            # Pass host and port to the benchmark loop
            result = self._benchmark_loop(
                pool, algo, miner.name, proc, pool_params.api_host, pool_params.api_port
            )
            return result.hashrate
        finally:
            # Ensure process is terminated
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
            
            # Post-benchmark cleanup to ensure next run is clean
            kill_zombies()
    
    def _benchmark_loop(self, pool: Pool, algo: str, miner_name: str,
                       proc: subprocess.Popen, api_host: str, api_port: int) -> BenchmarkResult:
        """Main benchmark loop."""
        max_hashrate = 0
        current_hashrate = 0
        accepted_shares = 0
        rejected_shares = 0
        revenue = 0.0

        # List to store valid hashrate samples for averaging
        hashrate_samples = []

        start_time = time.time()
        end_time = start_time + self.config["benchmark_period"]
        give_up_time = start_time + self.config["give_up_benchmark_low_profit_secs"]

        while True:
            # Check termination conditions
            current_time = time.time()

            if current_time >= end_time:
                logger.info("Benchmark period completed")
                break

            if accepted_shares >= self.config["complete_benchmark_min_shares"]:
                logger.info(f"Reached minimum shares ({accepted_shares})")
                break

            if rejected_shares >= self.config["max_rejected_shares"]:
                logger.warning(f"Too many rejected shares ({rejected_shares})")
                break

            if current_time >= give_up_time and revenue < self.config["min_profit"]:
                logger.warning(f"Low profitability (${revenue:.4f}/day), giving up")
                break

            # Get current stats
            try:
                # Initialize profit to avoid UnboundLocalError
                profit = 0.0

                hashrate, accepted_shares, rejected_shares = self.api_client.get_hashrate_and_shares(api_host, api_port)
                current_hashrate = hashrate

                # Only add to average if hashrate is non-zero (skip warmup zeros)
                if current_hashrate > 0:
                    hashrate_samples.append(current_hashrate)

                if current_hashrate > max_hashrate:
                    max_hashrate = current_hashrate

                if current_hashrate > 0:
                    profit = self.profit_calc.calculate_for_pool(pool, algo, current_hashrate)
                    revenue = profit

                # Progress display
                time_left = int(end_time - current_time) if revenue > self.config["min_profit"] else int(give_up_time - current_time)
                
                # Use inline truncation for display only
                algo_disp = algo[:9] + "." if len(algo) > 10 else algo
                
                # ANSI clear line
                CLEAR_LINE = "\033[K"
                
                print(f"\r{CLEAR_LINE}[{miner_name} {algo_disp}]({time_left}s) $: ${profit:.4f}/d "
                      f"S: {accepted_shares}A/{rejected_shares}R "
                      f"H: {int(current_hashrate)}/↑:{int(max_hashrate)}", end="", flush=True)

            except Exception as e:
                logger.warning(f"Error getting miner stats: {e}")

            # Check if process is still running
            if proc.poll() is not None:
                logger.error("Miner process terminated unexpectedly")
                break

            time.sleep(1)

        print()  # New line after progress display

        duration = time.time() - start_time

        # Calculate the REAL Average
        if hashrate_samples:
            avg_hashrate = sum(hashrate_samples) / len(hashrate_samples)
        else:
            avg_hashrate = 0.0

        # Logic: We save the AVERAGE, not the current/last reading
        final_hashrate = avg_hashrate

        result = BenchmarkResult(
            algo=algo,
            hashrate=final_hashrate,
            accepted_shares=accepted_shares,
            rejected_shares=rejected_shares,
            duration=duration
        )

        if accepted_shares == 0:
            logger.warning("No accepted shares during benchmark!")

        logger.info(f"Benchmark complete: {final_hashrate:.2f} H/s (Avg) ({accepted_shares} shares in {duration:.1f}s)")

        return result