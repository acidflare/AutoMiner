"""Interactive setup wizard for AutoMiner."""

import json
import os
import sys
from pathlib import Path
from typing import Dict, Any, Optional

# --- Configuration Paths ---
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / 'data'
CONFIG_FILE = DATA_DIR / 'config.json'
POOLS_FILE = DATA_DIR / 'pools.json'

# --- Helper Functions ---

def prompt_input(message: str, default: Optional[str] = None) -> str:
    """Prompts the user for input with an optional default value."""
    if default:
        user_input = input(f"{message} (Default: {default}): ")
        return user_input.strip() or default
    return input(f"{message}: ").strip()

def load_json(filepath: Path) -> Dict[str, Any]:
    """Safely loads a JSON file."""
    if not filepath.exists():
        return {}
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        print(f"[ERROR] Invalid JSON in {filepath.name}. Starting fresh.")
        return {}

def save_json(filepath: Path, data: Dict[str, Any]) -> None:
    """Saves data to a JSON file with formatting."""
    try:
        # Ensure directory exists
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)
        print(f"[INFO] Updated {filepath.name}")
    except Exception as e:
        print(f"[ERROR] Failed to write to {filepath.name}: {e}")
        sys.exit(1)

# --- Main Setup Logic ---

def main():
    print("=====================================================")
    print("                AutoMiner Setup Wizard               ")
    print("=====================================================")
    
    # Check if data directory exists
    if not DATA_DIR.exists():
        print(f"[ERROR] Data directory not found at: {DATA_DIR}")
        print("Please ensure you have unpacked the project correctly.")
        sys.exit(1)

    # 1. Load existing data
    config_data = load_json(CONFIG_FILE)
    pools_data = load_json(POOLS_FILE)

    # Defaults (using values from config if they exist, otherwise hard defaults)
    default_worker = config_data.get('worker_name', 'AutoMiner')
    default_payout = config_data.get('payout_coin', 'LTC')
    default_currency = config_data.get('currency', 'USD')
    
    # Try to extract an existing wallet from pools.json for the default
    default_wallet = "Your_Wallet_Address"
    if pools_data and "zpool" in pools_data:
        current_wallet = pools_data["zpool"].get("wallet", "")
        if current_wallet and current_wallet != "WALLET":
            default_wallet = current_wallet

    # 2. Prompt for user details
    print("\n--- Worker Configuration ---")
    worker_name = prompt_input("Enter Worker Name (e.g., AutoMiner)", default_worker)
    payout_coin = prompt_input("Enter Payout Coin (e.g., LTC, BTC)", default_payout)
    
    print("\n--- Wallet Configuration ---")
    wallet_address = prompt_input(f"Enter your {payout_coin} Wallet Address", default_wallet)
    
    print("\n--- Global Settings ---")
    currency = prompt_input("Enter Display Currency (e.g., USD, CAD, EUR, GBP)", default_currency)

    # 3. Process Logic
    
    # --- Update config.json ---
    # Add/Update the missing keys in your current config.json
    config_data['worker_name'] = worker_name
    config_data['payout_coin'] = payout_coin
    config_data['currency'] = currency.upper()
    
    # Ensure log/temp paths are defined (missing in your current file)
    if 'log_folder' not in config_data: config_data['log_folder'] = 'logs/'
    if 'temp_folder' not in config_data: config_data['temp_folder'] = 'temp/'
    
    # --- Update pools.json ---
    # Specifically targeting the 'zpool' entry and its 'wallet'/'password' keys
    if "zpool" not in pools_data:
        print("[WARN] 'zpool' entry missing in pools.json! Creating it...")
        pools_data["zpool"] = {
            "wallet": wallet_address,
            "password": f"{worker_name},c={payout_coin},stats",
            "mine_url": "stratum+tcp://{algo}.mine.zpool.ca:{port}",
            "api_url": "https://www.zpool.ca/api/status"
        }
    else:
        # Update existing entry
        pools_data["zpool"]["wallet"] = wallet_address
        # Construct password: WORKER,c=COIN,stats
        new_password = f"{worker_name},c={payout_coin},stats"
        pools_data["zpool"]["password"] = new_password

    # 4. Save Changes
    print("\n--- Saving Configuration ---")
    save_json(CONFIG_FILE, config_data)
    save_json(POOLS_FILE, pools_data)

    print("\n=====================================================")
    print("               Setup Complete!                       ")
    print("=====================================================")
    print(f"Worker:   {worker_name}")
    print(f"Payout:   {payout_coin}")
    print(f"Wallet:   {wallet_address}")
    print(f"Password: {new_password}")
    print("-----------------------------------------------------")
    print("You can now run: python3 AutoMiner.py")

if __name__ == "__main__":
    main()
