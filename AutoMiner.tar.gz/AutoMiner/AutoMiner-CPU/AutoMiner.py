#!/usr/bin/env python3
"""AutoMiner main executable."""

from core.main import main

if __name__ == "__main__":
    main()
