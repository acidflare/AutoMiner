#!/bin/bash

# ====================================================================
# START SUITE WRAPPER SCRIPT
# This script prepares the environment, installs CM Switcher dependencies,
# and runs the interactive setup wizard for the end-user.
# Designed for ARM64 Linux/Termux systems (like Sony XA2).
# ====================================================================

echo "=========================================================="
echo "      ARM64_Termux-AutoMiner: Initial Setup and Dependency Check  "
echo "=========================================================="

# --- 1. Detect Distribution and Determine Package Manager ---
if command -v apt &> /dev/null; then
    PKG_MANAGER="apt"
elif command -v pacman &> /dev/null; then
    PKG_MANAGER="pacman"
else
    echo "ERROR: Neither 'apt' (Debian/Ubuntu/Termux) nor 'pacman' (Arch/Garuda) found."
    echo "Please ensure you are running this in a compatible Linux or Termux environment."
    exit 1
fi

echo "--> Detected package manager: $PKG_MANAGER"

# --- 2. Install Python and Pip ---
echo "--> Installing Python 3 and pip..."

if [ "$PKG_MANAGER" == "apt" ]; then
    # Termux/Debian/Ubuntu packages
    apt upgrade -y
    apt install -y python3-is-python python python3 python3-pip python3-requests python3-tabulate python3-setuptools
elif [ "$PKG_MANAGER" == "pacman" ]; then
    # Arch/Garuda packages
    pacman -Sy --noconfirm python python-requests python-tabulate python-setuptools python-pip
fi

# Use python3 alias if available, otherwise fallback to python
PYTHON_CMD="python3"
if ! command -v $PYTHON_CMD &> /dev/null; then
    PYTHON_CMD="python"
fi

if ! command -v $PYTHON_CMD &> /dev/null; then
    echo "ERROR: Python installation failed. Cannot continue."
    exit 1
fi
echo "--> Using Python executable: $PYTHON_CMD"


# --- 3. Install Python Dependencies Directly ---
echo "--> Installing core Python dependencies (requests, setuptools, tabulate) via pip..."

# Install required packages directly, simplifying the dependency management
$PYTHON_CMD -m pip install --upgrade pip
$PYTHON_CMD -m pip install requests setuptools tabulate

# --- 4. Launch Interactive Setup Wizard ---
echo -e "\n=========================================================="
echo "         Launching Interactive User Configuration           "
echo "=========================================================="
if [ -f "initial_setup.py" ]; then
    $PYTHON_CMD initial_setup.py
else
    echo "ERROR: initial_setup.py not found. Setup wizard cannot be launched."
    exit 1
fi

echo -e "\n=========================================================="
echo "Setup Complete. You can now run the main CM Switcher script."
echo "=========================================================="
